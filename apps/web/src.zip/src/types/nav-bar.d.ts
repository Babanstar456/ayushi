export type NavItem = {
  path: string;
  label: string;
}
