export const range = (length: number): number[] => Array.from({ length }, (_, i) => i)
