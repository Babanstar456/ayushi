import NavBar  from "./nav-bar";

export default NavBar;
