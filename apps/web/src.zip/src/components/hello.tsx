'use client'

import { useEffect } from 'react'

function Hello() {
  useEffect(() => {
    console.log(`
Hi This is Ayushi Kundu
`)
  }, [])

  return null
}

export default Hello
